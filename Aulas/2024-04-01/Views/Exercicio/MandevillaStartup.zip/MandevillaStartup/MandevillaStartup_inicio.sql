/*
Instituto Federal do Tocantins - IFTO Campus Araguaína
01 de abril de 2024 (2024-04-01), segunda-feira
Curso: Análise e Desenvolvimento de Sistemas (CST)
Estudante: Juan Felipe Alves Flores             Período: 3°
Professor: Gilvan Vieira Moura                  Disciplina: Banco de Dados II
*/

CREATE DATABASE MandevillaStartup;

USE MandevillaStartup;