SELECT * FROM Departamentos;
SELECT * FROM Colaboradores;
SELECT * FROM Projetos;
SELECT * FROM Trabalhos;
