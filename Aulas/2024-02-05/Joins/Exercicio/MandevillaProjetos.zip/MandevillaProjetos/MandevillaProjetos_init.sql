CREATE DATABASE MandevillaProjetos;

USE MandevillaProjetos;