# Exercício 1 - Operadores Auxiliares

1. Faça duas consultas diferentes utilizando a função **IS NULL** para encontrar registros com valores nulos em campos específicos.

2. Realize três consultas diferentes utilizando a função **LIKE** para buscar registros que correspondam a padrões de caracteres específicos em campos de texto.

3. Execute duas consultas distintas utilizando a função **IN** para encontrar registros que correspondam a valores específicos de uma lista predefinida.

4. Realize três consultas diferentes utilizando a função **BETWEEN** para buscar registros dentro de intervalos específicos em campos numéricos.

5. Faça duas consultas em tabelas diferentes utilizando a função **AVG** para calcular a média de valores em campos numéricos.

6. Execute três consultas em tabelas diferentes utilizando a função **COUNT** para contar o número de registros que atendem a condições específicas.

7. Realize duas consultas em tabelas diferentes utilizando a função **MAX** para encontrar os valores máximos em campos numéricos.

8. Faça duas consultas em tabelas diferentes utilizando a função **MIN** para encontrar os valores mínimos em campos numéricos.

9. Execute três consultas diferentes utilizando a função **SUM** para calcular a soma de valores em campos numéricos.

<hr></hr>

Data: 29 de janeiro de 2024 (2024-01-29)