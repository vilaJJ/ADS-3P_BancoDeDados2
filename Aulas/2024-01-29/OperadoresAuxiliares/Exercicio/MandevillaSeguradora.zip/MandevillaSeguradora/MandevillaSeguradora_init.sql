CREATE DATABASE MandevillaSeguradora;

USE MandevillaSeguradora;