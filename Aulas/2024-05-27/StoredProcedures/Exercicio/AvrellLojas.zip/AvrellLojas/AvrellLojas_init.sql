/*
Instituto Federal do Tocantins - IFTO Campus Araguaína
27 de maio de 2024 (2024-05-27), segunda-feira
Curso: Análise e Desenvolvimento de Sistemas (CST)
Estudante: Juan Felipe Alves Flores             Período: 3°
Professor: Gilvan Vieira Moura                  Disciplina: Banco de Dados II
*/

CREATE DATABASE AvrellLojas;

USE AvrellLojas;